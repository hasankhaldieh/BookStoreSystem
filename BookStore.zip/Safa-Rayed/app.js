let cart = [];
let total = 0;

// Event listener for adding books to cart
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', (event) => {
        const title = event.target.getAttribute('data-title');
        const price = parseFloat(event.target.getAttribute('data-price'));
        const quantity = parseInt(event.target.previousElementSibling.querySelector('input').value, 10);
        
        // Add the selected item to the cart
        addToCart({ title, price, quantity });
    });
});

// Function to add items to the cart
function addToCart(item) {
    const cartList = document.querySelector('#cart-list');
    const li = document.createElement('li');
    li.classList.add('cart-item');
    
    li.innerHTML = `
        <span class="item-name">${item.title}</span> - 
        <span class="item-quantity">
            <input type="number" value="${item.quantity}" min="1">
        </span> 
        <span class="item-price">USD ${(item.price * item.quantity).toFixed(2)}</span>
        <button class="remove-item">Remove</button>
    `;
    
    // Add remove button functionality
    const removeButton = li.querySelector('.remove-item');
    removeButton.addEventListener('click', () => removeFromCart(item, li));
    
    cartList.appendChild(li);
    
    // Add to cart array and update total
    cart.push(item);
    total += item.price * item.quantity;
    updateTotal();
}

// Function to remove items from the cart
function removeFromCart(item, li) {
    const cartList = document.querySelector('#cart-list');
    
    // Remove item from cart array and subtract from total
    const index = cart.indexOf(item);
    if (index > -1) {
        cart.splice(index, 1);
        total -= item.price * item.quantity;
    }
    
    // Remove item from the DOM
    cartList.removeChild(li);
    
    updateTotal();
}

// Function to update the total price
function updateTotal() {
    const totalDisplay = document.querySelector('#cart-total');
    totalDisplay.textContent = `$${total.toFixed(2)}`; // Show total in USD

    if (cart.length === 0) {
        totalDisplay.textContent = `$0.00`;
    }
}

// Apply Discount Logic
document.querySelector('#apply-discount').addEventListener('click', () => {
    const discountCode = document.querySelector('#discount-code').value.trim();
    
    let discountApplied = false; // Flag to check if discount was applied

    if (discountCode === "DISCOUNT10") {
        total *= 0.9; // Apply a 10% discount
        discountApplied = true;
    } else if (discountCode === "SAVE20") {
        total *= 0.8; // Apply a 20% discount
        discountApplied = true;
    } else if (discountCode === "SUMMER2024") {
        total *= 0.7; // Apply a 30% discount
        discountApplied = true;
    } 

    if (discountApplied) {
        // Show an alert with the new price after discount
        alert(`Discount applied! New total: USD ${total.toFixed(2)}`);
    } else {
        alert("Invalid discount code.");
    }

    // Update the total display after applying the discount
    updateTotal(); // Update the total after applying the discount
});

// Checkout Button Logic
document.querySelector('#checkout').addEventListener('click', () => {
    if (cart.length === 0) {
        alert("Your cart is empty. Please add items to the cart before checking out.");
    } else {
        alert("Proceeding to checkout...");
        // You can add actual checkout logic here
    }
})
// Function to handle registration form submission
function submitRegisterForm() {
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    const mobileNumber = document.getElementById('mobileNumber').value;
    const icNumber = document.getElementById('icNumber').value;
    const gender = document.getElementById('gender').value;
    const address = document.getElementById('address').value;

    // Validate registration form
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        document.getElementById('register-error-message').textContent = "All fields are required!";
        return;
    }

    // Clear error messages
    document.getElementById('register-error-message').textContent = "";

    // Save data to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Hide register form and show order summary
    document.querySelector('.register').style.display = 'none';
    document.querySelector('.order-summary').style.display = 'block';
}

// Function to update the order summary
function updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address) {
    document.getElementById('summaryName').textContent = fullName;
    document.getElementById('summaryEmail').textContent = email;
    document.getElementById('summaryMobile').textContent = mobileNumber;
    document.getElementById('summaryIC').textContent = icNumber;
    document.getElementById('summaryGender').textContent = gender;
    document.getElementById('summaryAddress').textContent = address;
}

// Function to load profile data into Edit Profile form
function loadProfileData() {
    const fullName = localStorage.getItem('fullName');
    const email = localStorage.getItem('email');
    const mobileNumber = localStorage.getItem('mobileNumber');
    const icNumber = localStorage.getItem('icNumber');
    const gender = localStorage.getItem('gender');
    const address = localStorage.getItem('address');

    // Populate fields with data from localStorage
    document.getElementById('editFullName').value = fullName;
    document.getElementById('editEmail').value = email;
    document.getElementById('editMobileNumber').value = mobileNumber;
    document.getElementById('editICNumber').value = icNumber;
    document.getElementById('editGender').value = gender;
    document.getElementById('editAddress').value = address;
}

// Call loadProfileData to pre-fill the form with current data
loadProfileData();

// Function to update the profile with new data
function updateProfile() {
    const fullName = document.getElementById('editFullName').value;
    const email = document.getElementById('editEmail').value;
    const mobileNumber = document.getElementById('editMobileNumber').value;
    const icNumber = document.getElementById('editICNumber').value;
    const gender = document.getElementById('editGender').value;
    const address = document.getElementById('editAddress').value;

    // Validate Edit Profile form
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        document.getElementById('edit-error-message').textContent = "All fields are required!";
        return;
    }

    // Clear error messages
    document.getElementById('edit-error-message').textContent = "";

    // Save updated profile to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary with new data
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Show confirmation message
    alert("Profile updated successfully!");
}
// Function to handle registration form submission
function submitRegisterForm() {
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    const mobileNumber = document.getElementById('mobileNumber').value;
    const icNumber = document.getElementById('icNumber').value;
    const gender = document.getElementById('gender').value;
    const address = document.getElementById('address').value;

    // Validate registration form
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        document.getElementById('register-error-message').textContent = "All fields are required!";
        return;
    }

    // Clear error messages
    document.getElementById('register-error-message').textContent = "";

    // Save data to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Hide register form and show order summary
    document.querySelector('.register').style.display = 'none';
    document.querySelector('.order-summary').style.display = 'block';
    document.querySelector('.editprofile').style.display = 'block';
}

// Function to update the order summary
function updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address) {
    document.getElementById('summaryName').textContent = fullName;
    document.getElementById('summaryEmail').textContent = email;
    document.getElementById('summaryMobile').textContent = mobileNumber;
    document.getElementById('summaryIC').textContent = icNumber;
    document.getElementById('summaryGender').textContent = gender;
    document.getElementById('summaryAddress').textContent = address;
}

function updateProfile() {
    // Get the values from the Edit Profile form
    const fullName = document.getElementById('editFullName').value;
    const email = document.getElementById('editEmail').value;
    const mobileNumber = document.getElementById('editMobileNumber').value;
    const icNumber = document.getElementById('editICNumber').value;
    const gender = document.getElementById('editGender').value;
    const address = document.getElementById('editAddress').value;

    // Validate Edit Profile form: Check if any required fields are empty
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        // Show error message if any required field is empty
        alert(" you should fill out all fields!");
        return;
    }

    // Clear error message if all fields are filled out
    document.getElementById('edit-error-message').textContent = "";

    // Save updated data to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary with new data
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Optional: If you want to display a success message, alert or toast can be used
    alert("Profile updated successfully!");
}

// Function to update the order summary after saving data
function updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address) {
    document.getElementById('summaryName').textContent = fullName;
    document.getElementById('summaryEmail').textContent = email;
    document.getElementById('summaryMobile').textContent = mobileNumber;
    document.getElementById('summaryIC').textContent = icNumber;
    document.getElementById('summaryGender').textContent = gender;
    document.getElementById('summaryAddress').textContent = address;
}

// Function to load profile data into Edit Profile form (if available)
function loadProfileData() {
    const fullName = localStorage.getItem('fullName');
    const email = localStorage.getItem('email');
    const mobileNumber = localStorage.getItem('mobileNumber');
    const icNumber = localStorage.getItem('icNumber');
    const gender = localStorage.getItem('gender');
    const address = localStorage.getItem('address');

    // Populate fields with data from localStorage if it exists
    if (fullName) document.getElementById('editFullName').value = fullName;
    if (email) document.getElementById('editEmail').value = email;
    if (mobileNumber) document.getElementById('editMobileNumber').value = mobileNumber;
    if (icNumber) document.getElementById('editICNumber').value = icNumber;
    if (gender) document.getElementById('editGender').value = gender;
    if (address) document.getElementById('editAddress').value = address;
}

// Call loadProfileData to pre-fill the form with current data when the page loads
loadProfileData();
// Function to handle Edit Profile form submission
function updateProfile() {
    // Get the values from the Edit Profile form
    const fullName = document.getElementById('editFullName').value;
    const email = document.getElementById('editEmail').value;
    const mobileNumber = document.getElementById('editMobileNumber').value;
    const icNumber = document.getElementById('editICNumber').value;
    const gender = document.getElementById('editGender').value;
    const address = document.getElementById('editAddress').value;

    // Validate Edit Profile form: Check if any required fields are empty
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        // Show error message if any required field is empty
        document.getElementById('edit-error-message').textContent = "All fields are required! Please fill out all fields.";
        return;
    }

    // Clear error message if all fields are filled out
    alert(" you should fill out all fields!");

    // Save updated data to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary with new data
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Optional: If you want to display a success message, alert or toast can be used
    alert("Profile updated successfully!");
}

// Function to update the order summary after saving data
function updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address) {
    document.getElementById('summaryName').textContent = fullName;
    document.getElementById('summaryEmail').textContent = email;
    document.getElementById('summaryMobile').textContent = mobileNumber;
    document.getElementById('summaryIC').textContent = icNumber;
    document.getElementById('summaryGender').textContent = gender;
    document.getElementById('summaryAddress').textContent = address;
}

// Function to load profile data into Edit Profile form (if available)
function loadProfileData() {
    const fullName = localStorage.getItem('fullName');
    const email = localStorage.getItem('email');
    const mobileNumber = localStorage.getItem('mobileNumber');
    const icNumber = localStorage.getItem('icNumber');
    const gender = localStorage.getItem('gender');
    const address = localStorage.getItem('address');

    // Populate fields with data from localStorage if it exists
    if (fullName) document.getElementById('editFullName').value = fullName;
    if (email) document.getElementById('editEmail').value = email;
    if (mobileNumber) document.getElementById('editMobileNumber').value = mobileNumber;
    if (icNumber) document.getElementById('editICNumber').value = icNumber;
    if (gender) document.getElementById('editGender').value = gender;
    if (address) document.getElementById('editAddress').value = address;
}

// Call loadProfileData to pre-fill the form with current data when the page loads
loadProfileData();
// Function to handle Edit Profile form submission
function updateProfile() {
    // Get the values from the Edit Profile form
    const fullName = document.getElementById('editFullName').value;
    const email = document.getElementById('editEmail').value;
    const mobileNumber = document.getElementById('editMobileNumber').value;
    const icNumber = document.getElementById('editICNumber').value;
    const gender = document.getElementById('editGender').value;
    const address = document.getElementById('editAddress').value;

    // Validate Edit Profile form: Check if any required fields are empty
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        // Show alert error message if any required field is empty
        alert("All fields are required! Please fill out all fields.");
        return; // Prevent form submission
    }

    // Clear error message if all fields are filled out
    // No need to clear any message since we're using alert for error handling

    // Save updated data to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary with new data
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Optional: If you want to display a success message, alert or toast can be used
    alert("Profile updated successfully!");
}

// Function to update the order summary after saving data
function updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address) {
    document.getElementById('summaryName').textContent = fullName;
    document.getElementById('summaryEmail').textContent = email;
    document.getElementById('summaryMobile').textContent = mobileNumber;
    document.getElementById('summaryIC').textContent = icNumber;
    document.getElementById('summaryGender').textContent = gender;
    document.getElementById('summaryAddress').textContent = address;
}

// Function to load profile data into Edit Profile form (if available)
function loadProfileData() {
    const fullName = localStorage.getItem('fullName');
    const email = localStorage.getItem('email');
    const mobileNumber = localStorage.getItem('mobileNumber');
    const icNumber = localStorage.getItem('icNumber');
    const gender = localStorage.getItem('gender');
    const address = localStorage.getItem('address');

    // Populate fields with data from localStorage if it exists
    if (fullName) document.getElementById('editFullName').value = fullName;
    if (email) document.getElementById('editEmail').value = email;
    if (mobileNumber) document.getElementById('editMobileNumber').value = mobileNumber;
    if (icNumber) document.getElementById('editICNumber').value = icNumber;
    if (gender) document.getElementById('editGender').value = gender;
    if (address) document.getElementById('editAddress').value = address;
}

// Call loadProfileData to pre-fill the form with current data when the page loads
loadProfileData();
// Function to handle Edit Profile form submission
function updateProfile() {
    // Get the values from the Edit Profile form
    const fullName = document.getElementById('editFullName').value;
    const email = document.getElementById('editEmail').value;
    const mobileNumber = document.getElementById('editMobileNumber').value;
    const icNumber = document.getElementById('editICNumber').value;
    const gender = document.getElementById('editGender').value;
    const address = document.getElementById('editAddress').value;

    // Validate Edit Profile form: Check if any required fields are empty
    if (!fullName || !email || !mobileNumber || !icNumber || !gender || !address) {
        // Show alert error message if any required field is empty
        alert("All fields are required! Please fill out all fields.");
        return; // Prevent form submission
    }

    // Clear error message if all fields are filled out
    // No need to clear any message since we're using alert for error handling

    // Save updated data to localStorage
    localStorage.setItem('fullName', fullName);
    localStorage.setItem('email', email);
    localStorage.setItem('mobileNumber', mobileNumber);
    localStorage.setItem('icNumber', icNumber);
    localStorage.setItem('gender', gender);
    localStorage.setItem('address', address);

    // Update the order summary with new data
    updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address);

    // Optional: If you want to display a success message, alert or toast can be used
    alert("Profile updated successfully!");
}

// Function to update the order summary after saving data
function updateOrderSummary(fullName, email, mobileNumber, icNumber, gender, address) {
    document.getElementById('summaryName').textContent = fullName;
    document.getElementById('summaryEmail').textContent = email;
    document.getElementById('summaryMobile').textContent = mobileNumber;
    document.getElementById('summaryIC').textContent = icNumber;
    document.getElementById('summaryGender').textContent = gender;
    document.getElementById('summaryAddress').textContent = address;
}

// Function to load profile data into Edit Profile form (if available)
function loadProfileData() {
    const fullName = localStorage.getItem('fullName');
    const email = localStorage.getItem('email');
    const mobileNumber = localStorage.getItem('mobileNumber');
    const icNumber = localStorage.getItem('icNumber');
    const gender = localStorage.getItem('gender');
    const address = localStorage.getItem('address');

    // Populate fields with data from localStorage if it exists
    if (fullName) document.getElementById('editFullName').value = fullName;
    if (email) document.getElementById('editEmail').value = email;
    if (mobileNumber) document.getElementById('editMobileNumber').value = mobileNumber;
    if (icNumber) document.getElementById('editICNumber').value = icNumber;
    if (gender) document.getElementById('editGender').value = gender;
    if (address) document.getElementById('editAddress').value = address;
}

// Call loadProfileData to pre-fill the form with current data when the page loads
loadProfileData();